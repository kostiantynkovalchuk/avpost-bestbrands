# AV Post №2 — build notes for Replit Agent

Scope: this is the complete Issue №2 `index.html` (CSS + markup + bilingual text + JS). Do NOT rewrite markup or CSS. Tasks:

1. Create `images/` and place all 49 files per IMAGE_MAP.md. Portraits for 4 interviewees are inside the `.doc` files (unzip is not possible for .doc — use `antiword`/`libreoffice --convert-to docx` then unzip `word/media/`).
2. Run `python3 inline_images.py --in-place`. Confirm zero MISSING.
3. Open on 390px / 768px / 1100px. For every `.person-photo`, `.photo-card img`, `.record-col img` adjust ONLY the inline `object-position` to frame faces. Do not touch other CSS.
4. Verify: language toggle (both buttons + touchend), 12 horoscope cards open/close, both carousels scroll with arrows ≥768px and swipe <768px, counter updates.
5. Commit: `git commit --amend --reset-author` after your commit, per repo convention.

Rules carried from Issue №1: images inline base64 only; every text in `<span class="t" data-ua data-ru>`; mobile-first, edits inside media queries only; «бренді» never «коньяк».
